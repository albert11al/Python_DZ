multiplication = 15 * 3
division = 15 / 3
without_a_remainder = 15 // 2
degree = 15 ** 2
print(type(multiplication), type(division), type(without_a_remainder), type(degree))
