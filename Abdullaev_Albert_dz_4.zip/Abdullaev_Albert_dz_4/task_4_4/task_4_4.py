import MyMod_Currency

print(MyMod_Currency.currency_rates("eur"))
